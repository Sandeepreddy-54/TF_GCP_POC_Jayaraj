# datacoe-sma-dataplatform_prototype
Code repository for application 'dataplatform_prototype' for the Data Platform Prototype project of the Data CoE. This is used by Jeyaraj to build prototype applications for the Data Platform. Please do only pull and do not push to this repository while prototype development is ongoing.
