#!/bin/bash

################################################################################
# Apply Dataplex Aspects Script
# This script helps apply aspect metadata to data assets
################################################################################

set -e

# Configuration
PROJECT_ID="prusandbx-nprd-uat-iywjo9"
REGION="asia-southeast1"
PREFIX="ml-platform"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Function to print colored output
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

################################################################################
# Helper Functions
################################################################################

# Function to apply data classification aspect
apply_data_classification() {
    local entry_id=$1
    local classification_level=$2
    local data_owner=$3
    local retention_days=$4
    
    print_info "Applying data classification aspect to ${entry_id}..."
    
    # Create or update entry with classification aspect
    gcloud dataplex entries update ${entry_id} \
        --location=${REGION} \
        --project=${PROJECT_ID} \
        --aspects="{
            \"projects/${PROJECT_ID}/locations/${REGION}/aspectTypes/${PREFIX}-data-classification\": {
                \"data\": {
                    \"classification_level\": \"${classification_level}\",
                    \"data_owner\": \"${data_owner}\",
                    \"retention_days\": ${retention_days},
                    \"last_reviewed\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",
                    \"compliance_tags\": [\"GDPR\", \"Internal Policy\"]
                }
            }
        }" 2>/dev/null || {
        print_warning "Could not update entry ${entry_id}. It might not exist yet."
    }
}

# Function to apply data quality aspect
apply_data_quality() {
    local entry_id=$1
    local quality_score=$2
    local completeness=$3
    local accuracy=$4
    
    print_info "Applying data quality aspect to ${entry_id}..."
    
    gcloud dataplex entries update ${entry_id} \
        --location=${REGION} \
        --project=${PROJECT_ID} \
        --aspects="{
            \"projects/${PROJECT_ID}/locations/${REGION}/aspectTypes/${PREFIX}-data-quality\": {
                \"data\": {
                    \"overall_score\": ${quality_score},
                    \"completeness_percent\": ${completeness},
                    \"accuracy_percent\": ${accuracy},
                    \"last_validated\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",
                    \"validation_method\": \"AUTOMATED\"
                }
            }
        }" 2>/dev/null || {
        print_warning "Could not update entry ${entry_id}. It might not exist yet."
    }
}

# Function to apply ML dataset aspect
apply_ml_dataset() {
    local entry_id=$1
    local dataset_type=$2
    local ml_task=$3
    local target_variable=$4
    local feature_count=$5
    
    print_info "Applying ML dataset aspect to ${entry_id}..."
    
    gcloud dataplex entries update ${entry_id} \
        --location=${REGION} \
        --project=${PROJECT_ID} \
        --aspects="{
            \"projects/${PROJECT_ID}/locations/${REGION}/aspectTypes/${PREFIX}-ml-dataset\": {
                \"data\": {
                    \"dataset_type\": \"${dataset_type}\",
                    \"ml_task\": \"${ml_task}\",
                    \"target_variable\": \"${target_variable}\",
                    \"feature_count\": ${feature_count},
                    \"created_by\": \"$(gcloud config get-value account)\",
                    \"created_date\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",
                    \"version\": \"v1.0\",
                    \"bias_analysis_completed\": false
                }
            }
        }" 2>/dev/null || {
        print_warning "Could not update entry ${entry_id}. It might not exist yet."
    }
}

################################################################################
# Main Functions
################################################################################

# Function to list available aspect types
list_aspect_types() {
    print_info "Available Aspect Types:"
    echo ""
    
    gcloud dataplex aspect-types list \
        --location=${REGION} \
        --project=${PROJECT_ID} \
        --format="table(name.basename(),displayName,description)" 2>/dev/null || {
        print_error "Could not list aspect types. Make sure Dataplex is enabled and you have permissions."
    }
}

# Function to list entries
list_entries() {
    print_info "Current Dataplex Entries:"
    echo ""
    
    gcloud dataplex entries list \
        --location=${REGION} \
        --project=${PROJECT_ID} \
        --format="table(name.basename(),entryType,fullyQualifiedName)" 2>/dev/null || {
        print_error "Could not list entries."
    }
}

# Function to show entry details with aspects
show_entry_details() {
    local entry_id=$1
    
    if [ -z "$entry_id" ]; then
        print_error "Please provide an entry ID"
        return 1
    fi
    
    print_info "Entry details for: ${entry_id}"
    echo ""
    
    gcloud dataplex entries describe ${entry_id} \
        --location=${REGION} \
        --project=${PROJECT_ID} 2>/dev/null || {
        print_error "Entry ${entry_id} not found"
    }
}

# Interactive aspect application
interactive_apply() {
    print_info "Interactive Aspect Application"
    echo "=============================="
    echo ""
    
    # Show available entries
    list_entries
    echo ""
    
    read -p "Enter Entry ID to apply aspects to: " entry_id
    if [ -z "$entry_id" ]; then
        print_error "Entry ID is required"
        return 1
    fi
    
    echo ""
    echo "Available aspect types:"
    echo "1. Data Classification"
    echo "2. Data Quality"
    echo "3. ML Dataset"
    echo "4. All aspects"
    echo ""
    
    read -p "Select aspect type (1-4): " aspect_choice
    
    case $aspect_choice in
        1)
            read -p "Classification level (PUBLIC/INTERNAL/CONFIDENTIAL/RESTRICTED): " classification
            read -p "Data owner email: " owner
            read -p "Retention days: " retention
            apply_data_classification "$entry_id" "$classification" "$owner" "$retention"
            ;;
        2)
            read -p "Overall quality score (0-100): " quality
            read -p "Completeness percentage (0-100): " completeness
            read -p "Accuracy percentage (0-100): " accuracy
            apply_data_quality "$entry_id" "$quality" "$completeness" "$accuracy"
            ;;
        3)
            read -p "Dataset type (TRAINING/VALIDATION/TEST/INFERENCE): " ds_type
            read -p "ML task (CLASSIFICATION/REGRESSION/CLUSTERING/etc): " ml_task
            read -p "Target variable name: " target
            read -p "Number of features: " features
            apply_ml_dataset "$entry_id" "$ds_type" "$ml_task" "$target" "$features"
            ;;
        4)
            print_info "Applying all aspects with default values..."
            apply_data_classification "$entry_id" "INTERNAL" "data-owner@company.com" "365"
            apply_data_quality "$entry_id" "85.0" "90.0" "88.0"
            apply_ml_dataset "$entry_id" "TRAINING" "CLASSIFICATION" "target" "10"
            ;;
        *)
            print_error "Invalid choice"
            return 1
            ;;
    esac
    
    print_success "Aspects applied successfully!"
    echo ""
    print_info "View the entry details:"
    echo "gcloud dataplex entries describe ${entry_id} --location=${REGION} --project=${PROJECT_ID}"
}

################################################################################
# Usage and Main Script
################################################################################

show_usage() {
    echo "Usage: $0 [COMMAND]"
    echo ""
    echo "Commands:"
    echo "  list-types     List available aspect types"
    echo "  list-entries   List current entries"
    echo "  show ENTRY_ID  Show entry details with aspects"
    echo "  apply          Interactive aspect application"
    echo "  help           Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 list-types"
    echo "  $0 list-entries"
    echo "  $0 show ml-platform-raw-data-entry"
    echo "  $0 apply"
}

# Main script logic
case "${1:-help}" in
    "list-types")
        list_aspect_types
        ;;
    "list-entries")
        list_entries
        ;;
    "show")
        show_entry_details "$2"
        ;;
    "apply")
        interactive_apply
        ;;
    "help"|*)
        show_usage
        ;;
esac

print_info "Dataplex Aspect Management Complete!"