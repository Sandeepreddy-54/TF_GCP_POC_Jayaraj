#!/bin/bash

################################################################################
# Permission Checker Script for ML Data Platform
# This script validates that all required permissions are in place
################################################################################

set -e

# Configuration
PROJECT_ID="prusandbx-nprd-uat-iywjo9"
USER_EMAIL="jeyaraj.boominathan@prudential.com.sg"
REGION="asia-southeast1"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${BLUE}[CHECK]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

################################################################################
# Header
################################################################################

echo "=================================="
echo "ML Data Platform Permission Check"
echo "=================================="
echo ""
echo "Project: ${PROJECT_ID}"
echo "User: ${USER_EMAIL}"
echo ""

################################################################################
# Check gcloud CLI
################################################################################

print_info "Checking gcloud CLI..."
if command -v gcloud &> /dev/null; then
    print_success "gcloud CLI is installed"
    gcloud version --format="value(version.core)"
else
    print_error "gcloud CLI is not installed"
    exit 1
fi

################################################################################
# Check authentication
################################################################################

print_info "Checking authentication..."
ACTIVE_ACCOUNT=$(gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null)
if [ -n "$ACTIVE_ACCOUNT" ]; then
    print_success "Authenticated as: ${ACTIVE_ACCOUNT}"
else
    print_error "Not authenticated. Run: gcloud auth login"
    exit 1
fi

################################################################################
# Check project access
################################################################################

print_info "Checking project access..."
if gcloud projects describe ${PROJECT_ID} &>/dev/null; then
    print_success "Project ${PROJECT_ID} is accessible"
else
    print_error "Cannot access project ${PROJECT_ID}"
    exit 1
fi

################################################################################
# Check required roles
################################################################################

echo ""
echo "Checking IAM Roles:"
echo "-------------------"

# Get current roles for the user
CURRENT_ROLES=$(gcloud projects get-iam-policy ${PROJECT_ID} \
    --flatten="bindings[].members" \
    --filter="bindings.members:${USER_EMAIL}" \
    --format="value(bindings.role)" 2>/dev/null)

# Required roles for Terraform deployment
REQUIRED_ROLES=(
    "roles/resourcemanager.projectIamAdmin"
    "roles/iam.serviceAccountAdmin"
    "roles/compute.admin"
    "roles/storage.admin"
    "roles/bigquery.admin"
    "roles/aiplatform.admin"
    "roles/dataplex.admin"
    "roles/notebooks.admin"
    "roles/serviceusage.serviceUsageAdmin"
)

missing_roles=()
for role in "${REQUIRED_ROLES[@]}"; do
    if echo "${CURRENT_ROLES}" | grep -q "${role}"; then
        print_success "${role}"
    else
        print_warning "${role} - MISSING"
        missing_roles+=("${role}")
    fi
done

################################################################################
# Check API status
################################################################################

echo ""
echo "Checking API Status:"
echo "-------------------"

REQUIRED_APIS=(
    "aiplatform.googleapis.com"
    "bigquery.googleapis.com"
    "bigquerydatatransfer.googleapis.com"
    "bigqueryconnection.googleapis.com"
    "bigquerydatapolicy.googleapis.com"       # BigQuery Unified API
    "generativelanguage.googleapis.com"      # Gemini for Google Cloud
    "compute.googleapis.com"
    "dataplex.googleapis.com"
    "datacatalog.googleapis.com"
    "datalineage.googleapis.com"
    "notebooks.googleapis.com"
    "storage.googleapis.com"
    "storage-api.googleapis.com"
    "iam.googleapis.com"
    "logging.googleapis.com"
    "monitoring.googleapis.com"
    "serviceusage.googleapis.com"
    "cloudbuild.googleapis.com"
    "dataflow.googleapis.com"
    "pubsub.googleapis.com"
)

disabled_apis=()
for api in "${REQUIRED_APIS[@]}"; do
    if gcloud services list --enabled --filter="name:${api}" --project=${PROJECT_ID} --format="value(name)" 2>/dev/null | grep -q ${api}; then
        print_success "${api}"
    else
        print_warning "${api} - DISABLED"
        disabled_apis+=("${api}")
    fi
done

################################################################################
# Check quotas (basic check)
################################################################################

echo ""
echo "Checking Resource Quotas:"
echo "------------------------"

# Check compute quotas
print_info "Checking Compute Engine quotas..."
COMPUTE_QUOTA=$(gcloud compute project-info describe --project=${PROJECT_ID} --format="value(quotas[name=CPUS].limit)" 2>/dev/null)
if [ -n "$COMPUTE_QUOTA" ]; then
    print_success "CPU quota: ${COMPUTE_QUOTA}"
else
    print_warning "Could not retrieve CPU quota"
fi

################################################################################
# Check billing
################################################################################

echo ""
print_info "Checking billing account..."
BILLING_ENABLED=$(gcloud beta billing projects describe ${PROJECT_ID} --format="value(billingEnabled)" 2>/dev/null)
if [ "$BILLING_ENABLED" = "True" ]; then
    print_success "Billing is enabled"
else
    print_error "Billing is not enabled for this project"
fi

################################################################################
# Summary
################################################################################

echo ""
echo "=================================="
echo "Summary"
echo "=================================="
echo ""

# Count issues
total_issues=$((${#missing_roles[@]} + ${#disabled_apis[@]}))

if [ ${#missing_roles[@]} -gt 0 ]; then
    print_warning "Missing ${#missing_roles[@]} required IAM roles:"
    for role in "${missing_roles[@]}"; do
        echo "  - ${role}"
    done
    echo ""
    echo "To fix, run:"
    echo "  ./setup-iam-permissions.sh"
    echo ""
fi

if [ ${#disabled_apis[@]} -gt 0 ]; then
    print_warning "Found ${#disabled_apis[@]} disabled APIs:"
    for api in "${disabled_apis[@]}"; do
        echo "  - ${api}"
    done
    echo ""
    echo "To fix, run:"
    echo "  ./setup-iam-permissions.sh"
    echo ""
fi

if [ $total_issues -eq 0 ]; then
    print_success "✅ All permissions are correctly configured!"
    echo ""
    echo "You can proceed with Terraform deployment:"
    echo "  terraform init"
    echo "  terraform plan"
    echo "  terraform apply"
else
    print_error "❌ Found ${total_issues} permission issues that need to be fixed."
    echo ""
    echo "Run ./setup-iam-permissions.sh to fix these issues."
fi

echo ""

################################################################################
# Optional: Detailed permission test
################################################################################

read -p "Do you want to run a detailed permission test? (y/N): " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    echo "Running detailed permission tests..."
    echo "-----------------------------------"
    
    # Test creating a service account
    print_info "Testing service account creation..."
    TEST_SA="test-permission-check-$$"
    if gcloud iam service-accounts create ${TEST_SA} \
        --display-name="Test Permission Check" \
        --project=${PROJECT_ID} &>/dev/null; then
        print_success "Can create service accounts"
        gcloud iam service-accounts delete ${TEST_SA}@${PROJECT_ID}.iam.gserviceaccount.com \
            --quiet --project=${PROJECT_ID} &>/dev/null
    else
        print_error "Cannot create service accounts"
    fi
    
    # Test creating a GCS bucket
    print_info "Testing GCS bucket creation..."
    TEST_BUCKET="test-permission-check-$$"
    if gsutil mb -p ${PROJECT_ID} gs://${PROJECT_ID}-${TEST_BUCKET} &>/dev/null; then
        print_success "Can create GCS buckets"
        gsutil rm -r gs://${PROJECT_ID}-${TEST_BUCKET} &>/dev/null
    else
        print_error "Cannot create GCS buckets"
    fi
    
    # Test BigQuery dataset creation
    print_info "Testing BigQuery dataset creation..."
    TEST_DATASET="test_permission_check_$$"
    if bq mk --project_id=${PROJECT_ID} --dataset ${TEST_DATASET} &>/dev/null; then
        print_success "Can create BigQuery datasets"
        bq rm -f -d ${PROJECT_ID}:${TEST_DATASET} &>/dev/null
    else
        print_error "Cannot create BigQuery datasets"
    fi
    
    echo ""
    print_success "Detailed permission test completed"
fi