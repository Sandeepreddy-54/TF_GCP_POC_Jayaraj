# ML Data Platform - Terraform Template

A comprehensive Terraform template for deploying an end-to-end Machine Learning and Data Platform on Google Cloud Platform.

## Features

This template creates a complete ML infrastructure including:

### Data Infrastructure
- **BigQuery Datasets**: Raw data, processed data, ML features, and analytics datasets
- **Cloud Storage Buckets**: For raw data, processed data, ML artifacts, and Vertex AI staging
- **Sample Data**: Customer, product, and transaction tables with sample data generation scripts

### Data Governance (Dataplex)
- **Data Lake**: Centralized data lake with raw and curated zones
- **Data Assets**: Automated discovery and cataloging of BigQuery and GCS resources
- **Aspect Types**: Modern data catalog with structured metadata schemas for:
  - Data Classification (governance, compliance, ownership)
  - Data Quality (metrics, validation, completeness)
  - ML Dataset (model metadata, lineage, bias analysis)
  - Data Lineage (transformation history, dependencies)

### Machine Learning (Vertex AI)
- **Datasets**: Tabular datasets for ML use cases
- **Feature Store**: Centralized feature management with customer features
- **Model Endpoints**: Deployment endpoints for online predictions
- **Tensorboard**: Experiment tracking and visualization
- **Note**: Vertex AI Workbench removed from template (create manually if needed)

### Networking & Security
- **VPC Network**: Isolated network with private subnets
- **Cloud NAT**: Secure outbound internet access
- **Firewall Rules**: IAP access for secure connectivity
- **Service Accounts**: Dedicated accounts with least-privilege IAM roles

### Sample ML Workflow
- **Feature Engineering**: SQL scripts for creating ML features
- **BigQuery ML**: Native model training in BigQuery
- **Custom Training**: Python scripts for scikit-learn models
- **Pipeline Configuration**: End-to-end ML pipeline setup

## Prerequisites

1. Google Cloud Project with billing enabled
2. Terraform >= 1.3
3. Required APIs will be automatically enabled

## Usage

### 1. Configure Variables

Create a `terraform.tfvars` file:

```hcl
project_id = "prusandbx-nprd-uat-iywjo9"
region     = "asia-southeast1"
prefix     = "ml-platform"

# Optional: Customize environment
environment = "dev"
labels = {
  team = "data-science"
  cost-center = "analytics"
}

# Optional: Use existing network
use_existing_network = false

# Sample data configuration
create_sample_data = true
sample_data_config = {
  num_customers    = 10000
  num_transactions = 100000
  num_products     = 1000
}
```

### 2. Initialize Terraform

```bash
terraform init
```

### 3. Review the Plan

```bash
terraform plan
```

### 4. Deploy Infrastructure

```bash
terraform apply
```

### 5. Generate Sample Data

After deployment, populate BigQuery tables with sample data:

```bash
# Get bucket and dataset names from outputs
PROJECT_ID=$(terraform output -raw project_id)
ML_ARTIFACTS_BUCKET=$(terraform output -json storage_buckets | jq -r .ml_artifacts)

# Step 1: Generate sample customer, product, and transaction data
bq query --use_legacy_sql=false --project_id=$PROJECT_ID \
  "$(gsutil cat gs://${ML_ARTIFACTS_BUCKET}/scripts/generate_sample_data.sql)"

# Step 2: Create ML features from raw data
bq query --use_legacy_sql=false --project_id=$PROJECT_ID \
  "$(gsutil cat gs://${ML_ARTIFACTS_BUCKET}/scripts/feature_engineering.sql)"

# Step 3: Train BigQuery ML model (optional)
bq query --use_legacy_sql=false --project_id=$PROJECT_ID \
  "$(gsutil cat gs://${ML_ARTIFACTS_BUCKET}/scripts/create_bqml_model.sql)"

# Verify data generation
bq ls --project_id=$PROJECT_ID
bq head --project_id=$PROJECT_ID ml_platform_raw_data.sample_customers
```

### 6. Access Resources

After deployment, use the output commands to access your resources:

```bash
# Get deployment outputs
terraform output

# Get quick start commands
terraform output -raw quick_start_commands
```

## Project Structure

```
ml-data-platform/
├── main.tf                      # Core infrastructure and APIs
├── storage.tf                   # BigQuery and GCS resources
├── dataplex.tf                  # Data catalog and governance with Aspect Types
├── dataplex-aspects-example.tf  # Example aspect instances for data assets
├── vertex-ai.tf                 # ML platform components
├── sample-workflow.tf           # Example ML pipelines
├── variables.tf                 # Input variables
├── outputs.tf                   # Output values
├── apply-aspects.sh             # Script to apply aspects to data assets
├── terraform.tfvars.example     # Sample configuration file
└── README.md                    # This file
```

## Key Components

### BigQuery Datasets
- `{prefix}_raw_data`: Raw ingested data
- `{prefix}_processed_data`: Cleaned and transformed data
- `{prefix}_ml_features`: Feature engineering results
- `{prefix}_analytics`: Model outputs and analytics

### Storage Buckets
- `raw-data`: Landing zone for raw files
- `processed-data`: Transformed data storage
- `ml-artifacts`: Model artifacts and scripts
- `vertex-staging`: Vertex AI temporary files
- `dataplex-data`: Dataplex managed storage

### ML Capabilities
- **AutoML**: Use Vertex AI AutoML for automated model training
- **Custom Training**: Deploy custom training scripts
- **BigQuery ML**: Native SQL-based model training
- **Online Prediction**: Real-time model serving endpoints
- **Batch Prediction**: Large-scale batch inference

## Sample Data Workflow

The template includes a complete customer churn prediction workflow with configurable sample data:

### Data Generation Process

1. **Sample Tables Created**:
   - `sample_customers`: Customer demographics, segments, purchase history
   - `sample_products`: Product catalog with categories and pricing
   - `sample_transactions`: Transaction history linking customers and products

2. **Feature Engineering**:
   - `customer_features_enriched`: Aggregated customer metrics and behaviors
   - `training_dataset`: 80% split for model training
   - `test_dataset`: 20% split for model testing

3. **ML Model Creation**:
   - BigQuery ML boosted tree classifier for churn prediction
   - Model evaluation metrics stored in analytics dataset
   - Feature importance analysis for interpretability

### Data Volume Configuration

Control sample data volume via `terraform.tfvars`:
```hcl
sample_data_config = {
  num_customers    = 10000    # Number of customers to generate
  num_transactions = 100000   # Number of transactions to generate
  num_products     = 1000     # Number of products in catalog
}
```

## Cost Optimization

To minimize costs:
- Set `force_destroy = true` in dev environments
- Use lifecycle policies on storage buckets
- Configure auto-scaling for endpoints
- Schedule notebooks to stop when idle
- Use preemptible VMs for training

## Security Best Practices

- All resources use private IPs (no public exposure)
- Service accounts follow least-privilege principle
- Data encryption at rest (optional CMEK support)
- VPC Service Controls ready
- Audit logging enabled

## Cleanup

To destroy all resources:

```bash
terraform destroy
```

**Warning**: This will delete all data and resources. Set `force_destroy = false` to prevent accidental data deletion.

## Data Governance with Dataplex Aspect Types

### Available Aspect Types

The platform creates four modern aspect types for comprehensive data governance:

1. **Data Classification** (`ml-platform-data-classification`)
   - Classification levels: PUBLIC, INTERNAL, CONFIDENTIAL, RESTRICTED
   - Data ownership and stewardship information
   - Retention policies and compliance tags
   - Review timestamps and governance metadata

2. **Data Quality** (`ml-platform-data-quality`)
   - Overall quality scores (0-100)
   - Completeness, accuracy, consistency, validity percentages
   - Validation methods and timestamps
   - Detected issues and row counts

3. **ML Dataset** (`ml-platform-ml-dataset`)
   - Dataset types: TRAINING, VALIDATION, TEST, INFERENCE, FEATURE_STORE
   - ML task types: CLASSIFICATION, REGRESSION, etc.
   - Feature and record counts, target variables
   - Model compatibility and preprocessing steps
   - Bias analysis completion status

4. **Data Lineage** (`ml-platform-data-lineage`)
   - Source systems and transformation jobs
   - Pipeline information and run IDs
   - Processing frequency and timestamps
   - Upstream dependencies and downstream consumers

### Managing Aspects

#### Using the Apply Aspects Script
```bash
# Interactive aspect application
./apply-aspects.sh apply

# List available aspect types
./apply-aspects.sh list-types

# List entries with aspects
./apply-aspects.sh list-entries

# View entry details
./apply-aspects.sh show ENTRY_ID
```

#### Using gcloud CLI
```bash
# List aspect types
gcloud dataplex aspect-types list --location=asia-southeast1

# List entries with aspects
gcloud dataplex entries list --location=asia-southeast1

# View entry with applied aspects
gcloud dataplex entries describe ENTRY_ID --location=asia-southeast1
```

### Example Aspect Applications

The platform includes examples of applied aspects to:
- Raw customer data with classification and quality aspects
- ML training datasets with dataset and lineage aspects
- Analytics predictions with classification and lineage aspects

## Customization

### Adding New Datasets
Edit `storage.tf` to add new BigQuery datasets or tables.

### Modifying Network Configuration
Update networking settings in `main.tf` or use existing VPC via variables.

### Extending ML Capabilities
Add new Vertex AI resources in `vertex-ai.tf`.

### Custom Pipelines
Modify `sample-workflow.tf` to implement your specific ML workflows.

## Support

For issues or questions:
1. Check the [Terraform Google Provider Documentation](https://registry.terraform.io/providers/hashicorp/google/latest/docs)
2. Review [Vertex AI Documentation](https://cloud.google.com/vertex-ai/docs)
3. Consult [Dataplex Documentation](https://cloud.google.com/dataplex/docs)

## License

This template is provided as-is for educational and development purposes.