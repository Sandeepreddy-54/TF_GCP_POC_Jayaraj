#!/bin/bash

################################################################################
# API Enablement Script for ML Data Platform
# This script enables all required Google Cloud APIs for the platform
################################################################################

set -e

# Configuration - Update these values
PROJECT_ID="${1:-your-project-id}"
REGION="${2:-us-central1}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

################################################################################
# Header
################################################################################

echo "========================================="
echo "ML Data Platform - API Enablement Script"
echo "========================================="
echo ""

# Check if project ID was provided
if [ "$PROJECT_ID" == "your-project-id" ]; then
    echo "Usage: $0 <PROJECT_ID> [REGION]"
    echo "Example: $0 my-project-123 us-central1"
    exit 1
fi

echo "Project: ${PROJECT_ID}"
echo "Region: ${REGION}"
echo ""

# Check if gcloud is installed
if ! command -v gcloud &> /dev/null; then
    print_error "gcloud CLI is not installed. Please install it first:"
    echo "https://cloud.google.com/sdk/docs/install"
    exit 1
fi

# Set the project
print_info "Setting project to ${PROJECT_ID}..."
gcloud config set project ${PROJECT_ID} 2>/dev/null || {
    print_error "Failed to set project. Please check if project ID is correct."
    exit 1
}

################################################################################
# API List
################################################################################

print_info "Preparing to enable required APIs..."
echo ""

# Complete list of required APIs
REQUIRED_APIS=(
    # Core AI/ML APIs
    "aiplatform.googleapis.com"              # Vertex AI
    "notebooks.googleapis.com"               # Vertex AI Workbench
    "generativelanguage.googleapis.com"      # Gemini for Google Cloud
    
    # BigQuery APIs
    "bigquery.googleapis.com"                # BigQuery
    "bigquerydatatransfer.googleapis.com"    # BigQuery Data Transfer
    "bigqueryconnection.googleapis.com"      # BigQuery Connection
    "bigquerydatapolicy.googleapis.com"      # BigQuery Unified API
    
    # Data Governance APIs
    "dataplex.googleapis.com"                # Dataplex
    "datacatalog.googleapis.com"             # Data Catalog
    "datalineage.googleapis.com"             # Data Lineage
    
    # Storage & Compute APIs
    "storage.googleapis.com"                 # Cloud Storage
    "storage-api.googleapis.com"             # Cloud Storage API
    "compute.googleapis.com"                 # Compute Engine
    
    # Supporting Services
    "cloudbuild.googleapis.com"              # Cloud Build
    "cloudresourcemanager.googleapis.com"    # Resource Manager
    "container.googleapis.com"               # Container API
    "containerregistry.googleapis.com"       # Container Registry
    "dataflow.googleapis.com"                # Dataflow
    "iam.googleapis.com"                     # IAM
    "logging.googleapis.com"                 # Logging
    "monitoring.googleapis.com"              # Monitoring
    "pubsub.googleapis.com"                  # Pub/Sub
    "serviceusage.googleapis.com"            # Service Usage
)

################################################################################
# Enable APIs
################################################################################

echo "Enabling APIs (this may take a few minutes)..."
echo "================================================"

# Counter for progress
total=${#REQUIRED_APIS[@]}
current=0
failed_apis=()

for api in "${REQUIRED_APIS[@]}"; do
    current=$((current + 1))
    echo -ne "\rProgress: [$current/$total] Enabling ${api}..."
    
    if gcloud services enable ${api} --project=${PROJECT_ID} --quiet 2>/dev/null; then
        echo -e "\r${GREEN}[✓]${NC} [$current/$total] ${api}"
    else
        echo -e "\r${YELLOW}[⚠]${NC} [$current/$total] ${api} - May already be enabled or require permissions"
        failed_apis+=("${api}")
    fi
done

echo ""
echo "================================================"

################################################################################
# Verify APIs
################################################################################

print_info "Verifying enabled APIs..."
echo ""

# Check critical APIs
CRITICAL_APIS=(
    "aiplatform.googleapis.com"
    "bigquery.googleapis.com"
    "generativelanguage.googleapis.com"
    "bigquerydatapolicy.googleapis.com"
    "compute.googleapis.com"
    "storage.googleapis.com"
)

all_enabled=true
for api in "${CRITICAL_APIS[@]}"; do
    if gcloud services list --enabled --filter="name:${api}" --project=${PROJECT_ID} --format="value(name)" 2>/dev/null | grep -q ${api}; then
        print_success "${api} is enabled"
    else
        print_error "${api} is NOT enabled"
        all_enabled=false
    fi
done

################################################################################
# Region-specific checks
################################################################################

echo ""
print_info "Checking region-specific service availability..."

# Check if Dataplex is supported in the region
DATAPLEX_REGIONS=("us-central1" "us-east1" "us-west1" "us-west2" "europe-west1" "europe-west2" "europe-west3" "europe-west4" "asia-northeast1" "asia-northeast3")

if [[ " ${DATAPLEX_REGIONS[@]} " =~ " ${REGION} " ]]; then
    print_success "Dataplex is supported in ${REGION}"
else
    print_warning "Dataplex is NOT supported in ${REGION}. Dataplex features will be disabled."
    echo "         Supported regions: ${DATAPLEX_REGIONS[@]}"
fi

################################################################################
# Summary
################################################################################

echo ""
echo "========================================="
echo "Summary"
echo "========================================="

if [ ${#failed_apis[@]} -eq 0 ]; then
    print_success "All APIs processed successfully!"
else
    print_warning "Some APIs may require additional permissions:"
    for api in "${failed_apis[@]}"; do
        echo "  - ${api}"
    done
    echo ""
    echo "You may need to:"
    echo "1. Check if you have the 'Service Usage Admin' role"
    echo "2. Enable billing for the project"
    echo "3. Contact your organization administrator"
fi

if [ "$all_enabled" = true ]; then
    echo ""
    print_success "All critical APIs are enabled and ready!"
    echo ""
    echo "Next steps:"
    echo "1. Configure terraform.tfvars with your settings"
    echo "2. Run: terraform init"
    echo "3. Run: terraform plan"
    echo "4. Run: terraform apply"
else
    echo ""
    print_warning "Some critical APIs are not enabled. Please resolve before proceeding."
fi

echo ""
echo "To check API status at any time:"
echo "  gcloud services list --enabled --project=${PROJECT_ID}"
echo ""
echo "To manually enable an API:"
echo "  gcloud services enable <API_NAME> --project=${PROJECT_ID}"