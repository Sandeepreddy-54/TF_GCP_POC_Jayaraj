#!/bin/bash

################################################################################
# IAM Permission Setup Script for ML Data Platform
# This script grants necessary permissions to deploy the ML Data Platform
################################################################################

set -e  # Exit on error

# Configuration
PROJECT_ID="prusandbx-nprd-uat-iywjo9"
USER_EMAIL="jeyaraj.boominathan@prudential.com.sg"
REGION="asia-southeast1"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

################################################################################
# Pre-flight checks
################################################################################

print_info "Starting IAM permission setup for ML Data Platform..."
print_info "Project ID: ${PROJECT_ID}"
print_info "User Email: ${USER_EMAIL}"
echo ""

# Check if gcloud is installed
if ! command -v gcloud &> /dev/null; then
    print_error "gcloud CLI is not installed. Please install it first:"
    echo "https://cloud.google.com/sdk/docs/install"
    exit 1
fi

# Check if user is authenticated
print_info "Checking gcloud authentication..."
if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q .; then
    print_warning "Not authenticated. Please authenticate:"
    gcloud auth login
fi

# Set the project
print_info "Setting project to ${PROJECT_ID}..."
gcloud config set project ${PROJECT_ID} 2>/dev/null || {
    print_error "Failed to set project. Please ensure the project exists and you have access."
    exit 1
}

# Verify project access
print_info "Verifying project access..."
if ! gcloud projects describe ${PROJECT_ID} &>/dev/null; then
    print_error "Cannot access project ${PROJECT_ID}. Please check the project ID and your permissions."
    exit 1
fi

################################################################################
# Enable essential APIs first
################################################################################

print_info "Enabling essential APIs..."
ESSENTIAL_APIS=(
    "cloudresourcemanager.googleapis.com"
    "iam.googleapis.com"
    "serviceusage.googleapis.com"
)

for api in "${ESSENTIAL_APIS[@]}"; do
    print_info "Enabling ${api}..."
    gcloud services enable ${api} --project=${PROJECT_ID} --quiet 2>/dev/null || {
        print_warning "Could not enable ${api}. It might already be enabled or you lack permissions."
    }
done

# Wait for APIs to propagate
print_info "Waiting for API changes to propagate..."
sleep 5

################################################################################
# Define required IAM roles
################################################################################

# Roles needed for Terraform deployment
TERRAFORM_ROLES=(
    # Project level permissions
    "roles/resourcemanager.projectIamAdmin"
    "roles/iam.serviceAccountAdmin"
    "roles/iam.serviceAccountKeyAdmin"
    "roles/iam.roleAdmin"
    
    # Service enablement
    "roles/serviceusage.serviceUsageAdmin"
    
    # Compute and networking
    "roles/compute.admin"
    "roles/compute.networkAdmin"
    "roles/compute.securityAdmin"
    
    # Storage
    "roles/storage.admin"
    
    # BigQuery
    "roles/bigquery.admin"
    "roles/bigquery.dataOwner"
    
    # Vertex AI
    "roles/aiplatform.admin"
    "roles/notebooks.admin"
    
    # Dataplex
    "roles/dataplex.admin"
    "roles/datacatalog.admin"
    
    # Other services
    "roles/pubsub.admin"
    "roles/cloudbuild.builds.editor"
    "roles/logging.admin"
    "roles/monitoring.admin"
)

# Additional roles that might be needed depending on organization policies
OPTIONAL_ROLES=(
    "roles/orgpolicy.policyAdmin"
    "roles/compute.xpnAdmin"  # For Shared VPC
    "roles/resourcemanager.organizationAdmin"
)

################################################################################
# Function to check current roles
################################################################################

check_current_roles() {
    print_info "Checking current IAM roles for ${USER_EMAIL}..."
    echo ""
    echo "Current roles:"
    gcloud projects get-iam-policy ${PROJECT_ID} \
        --flatten="bindings[].members" \
        --filter="bindings.members:${USER_EMAIL}" \
        --format="table(bindings.role)" 2>/dev/null || {
        print_warning "Could not retrieve current roles"
    }
    echo ""
}

################################################################################
# Function to grant a single role
################################################################################

grant_role() {
    local role=$1
    local member="user:${USER_EMAIL}"
    
    print_info "Granting ${role}..."
    if gcloud projects add-iam-policy-binding ${PROJECT_ID} \
        --member="${member}" \
        --role="${role}" \
        --quiet \
        --no-user-output-enabled 2>/dev/null; then
        print_success "✓ Granted ${role}"
    else
        print_warning "✗ Could not grant ${role} (may already exist or insufficient permissions)"
    fi
}

################################################################################
# Main execution
################################################################################

echo "=================================="
echo "ML Data Platform IAM Setup"
echo "=================================="
echo ""

# Check current roles
check_current_roles

# Ask for confirmation
echo ""
print_warning "This script will grant the following roles to ${USER_EMAIL}:"
echo ""
for role in "${TERRAFORM_ROLES[@]}"; do
    echo "  - ${role}"
done
echo ""
read -p "Do you want to proceed? (y/N): " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    print_info "Setup cancelled by user"
    exit 0
fi

echo ""
print_info "Granting required IAM roles..."
echo ""

# Grant each role
for role in "${TERRAFORM_ROLES[@]}"; do
    grant_role "${role}"
done

echo ""
print_info "Checking for optional roles that might be needed..."
echo ""

# Check if user wants optional roles
print_warning "The following optional roles might be needed depending on your organization setup:"
echo ""
for role in "${OPTIONAL_ROLES[@]}"; do
    echo "  - ${role}"
done
echo ""
read -p "Do you want to grant optional roles as well? (y/N): " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    for role in "${OPTIONAL_ROLES[@]}"; do
        grant_role "${role}"
    done
fi

################################################################################
# Enable all required APIs
################################################################################

echo ""
print_info "Enabling all required Google Cloud APIs..."
echo ""

ALL_APIS=(
    "aiplatform.googleapis.com"
    "bigquery.googleapis.com"
    "bigquerydatatransfer.googleapis.com"
    "bigqueryconnection.googleapis.com"
    "bigquerydatapolicy.googleapis.com"       # BigQuery Unified API
    "generativelanguage.googleapis.com"      # Gemini for Google Cloud
    "cloudbuild.googleapis.com"
    "cloudresourcemanager.googleapis.com"
    "compute.googleapis.com"
    "container.googleapis.com"
    "containerregistry.googleapis.com"
    "dataflow.googleapis.com"
    "dataplex.googleapis.com"
    "datacatalog.googleapis.com"
    "datalineage.googleapis.com"
    "iam.googleapis.com"
    "logging.googleapis.com"
    "monitoring.googleapis.com"
    "notebooks.googleapis.com"
    "pubsub.googleapis.com"
    "serviceusage.googleapis.com"
    "storage-api.googleapis.com"
    "storage.googleapis.com"
)

for api in "${ALL_APIS[@]}"; do
    print_info "Enabling ${api}..."
    gcloud services enable ${api} --project=${PROJECT_ID} --quiet 2>/dev/null || {
        print_warning "Could not enable ${api}. It might already be enabled."
    }
done

################################################################################
# Create terraform service account (optional)
################################################################################

echo ""
read -p "Do you want to create a dedicated service account for Terraform? (y/N): " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    SA_NAME="terraform-deployer"
    SA_EMAIL="${SA_NAME}@${PROJECT_ID}.iam.gserviceaccount.com"
    
    print_info "Creating service account ${SA_NAME}..."
    gcloud iam service-accounts create ${SA_NAME} \
        --display-name="Terraform Deployer" \
        --description="Service account for Terraform deployments" \
        --project=${PROJECT_ID} 2>/dev/null || {
        print_warning "Service account might already exist"
    }
    
    print_info "Granting roles to service account..."
    for role in "${TERRAFORM_ROLES[@]}"; do
        gcloud projects add-iam-policy-binding ${PROJECT_ID} \
            --member="serviceAccount:${SA_EMAIL}" \
            --role="${role}" \
            --quiet \
            --no-user-output-enabled 2>/dev/null || {
            print_warning "Could not grant ${role} to service account"
        }
    done
    
    print_info "Creating service account key..."
    gcloud iam service-accounts keys create terraform-key.json \
        --iam-account=${SA_EMAIL} \
        --project=${PROJECT_ID} 2>/dev/null && {
        print_success "Service account key saved to terraform-key.json"
        print_warning "Keep this key secure and do not commit it to version control!"
        echo ""
        echo "To use this service account with Terraform, run:"
        echo "export GOOGLE_APPLICATION_CREDENTIALS=\"$(pwd)/terraform-key.json\""
    }
fi

################################################################################
# Verify setup
################################################################################

echo ""
print_info "Verifying setup..."
echo ""

# Check if key APIs are enabled
print_info "Checking API status..."
CRITICAL_APIS=("aiplatform.googleapis.com" "bigquery.googleapis.com" "dataplex.googleapis.com" "compute.googleapis.com")
all_apis_enabled=true

for api in "${CRITICAL_APIS[@]}"; do
    if gcloud services list --enabled --filter="name:${api}" --project=${PROJECT_ID} --format="value(name)" | grep -q ${api}; then
        print_success "✓ ${api} is enabled"
    else
        print_error "✗ ${api} is not enabled"
        all_apis_enabled=false
    fi
done

echo ""

# Final status
if [ "$all_apis_enabled" = true ]; then
    print_success "✅ Setup completed successfully!"
else
    print_warning "⚠️ Setup completed with warnings. Some APIs might need manual enabling."
fi

echo ""
print_info "Final IAM roles for ${USER_EMAIL}:"
gcloud projects get-iam-policy ${PROJECT_ID} \
    --flatten="bindings[].members" \
    --filter="bindings.members:${USER_EMAIL}" \
    --format="table(bindings.role)" 2>/dev/null

################################################################################
# Next steps
################################################################################

echo ""
echo "=================================="
echo "Next Steps"
echo "=================================="
echo ""
echo "1. Navigate to the Terraform directory:"
echo "   cd $(dirname $0)"
echo ""
echo "2. Initialize Terraform:"
echo "   terraform init"
echo ""
echo "3. Review the deployment plan:"
echo "   terraform plan"
echo ""
echo "4. Deploy the infrastructure:"
echo "   terraform apply"
echo ""
echo "5. If you created a service account, use it by setting:"
echo "   export GOOGLE_APPLICATION_CREDENTIALS=\"$(pwd)/terraform-key.json\""
echo ""

print_success "IAM setup complete! You can now proceed with Terraform deployment."