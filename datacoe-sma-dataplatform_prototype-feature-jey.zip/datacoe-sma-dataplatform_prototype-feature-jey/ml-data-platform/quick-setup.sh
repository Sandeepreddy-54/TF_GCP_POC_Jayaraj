#!/bin/bash

################################################################################
# Quick Setup Script - One-command setup for ML Data Platform
# This script combines permission setup and Terraform deployment
################################################################################

set -e

# Configuration
PROJECT_ID="prusandbx-nprd-uat-iywjo9"
USER_EMAIL="jeyaraj.boominathan@prudential.com.sg"
REGION="asia-southeast1"
PREFIX="ml-platform"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "\n${BOLD}📋 $1${NC}"
    echo "----------------------------------------"
}

################################################################################
# Banner
################################################################################

clear
cat << "EOF"
 __  __ _       ____        _          ____  _       _    __                      
|  \/  | |     |  _ \  __ _| |_ __ _  |  _ \| | __ _| |_ / _| ___  _ __ _ __ ___  
| |\/| | |     | | | |/ _` | __/ _` | | |_) | |/ _` | __| |_ / _ \| '__| '_ ` _ \ 
| |  | | |___  | |_| | (_| | || (_| | |  __/| | (_| | |_|  _| (_) | |  | | | | | |
|_|  |_|_____| |____/ \__,_|\__\__,_| |_|   |_|\__,_|\__|_|  \___/|_|  |_| |_| |_|
                                                                                   
EOF

echo -e "${BOLD}Google Cloud ML & Data Platform - Quick Setup${NC}"
echo "================================================="
echo ""
echo "Project ID: ${PROJECT_ID}"
echo "User Email: ${USER_EMAIL}"
echo "Region: ${REGION}"
echo ""

################################################################################
# Pre-flight checks
################################################################################

log_step "Pre-flight Checks"

# Check for required tools
REQUIRED_TOOLS=("gcloud" "terraform" "git")
missing_tools=()

for tool in "${REQUIRED_TOOLS[@]}"; do
    if command -v $tool &> /dev/null; then
        log_success "$tool is installed ($(which $tool))"
    else
        log_error "$tool is not installed"
        missing_tools+=($tool)
    fi
done

if [ ${#missing_tools[@]} -gt 0 ]; then
    echo ""
    log_error "Missing required tools: ${missing_tools[*]}"
    echo ""
    echo "Installation instructions:"
    echo "- gcloud: https://cloud.google.com/sdk/docs/install"
    echo "- terraform: https://www.terraform.io/downloads"
    echo "- git: https://git-scm.com/downloads"
    exit 1
fi

# Check Terraform version
TERRAFORM_VERSION=$(terraform version -json 2>/dev/null | grep -o '"terraform_version":"[^"]*' | cut -d'"' -f4)
log_info "Terraform version: ${TERRAFORM_VERSION}"

################################################################################
# Authentication
################################################################################

log_step "Authentication Setup"

# Check if authenticated
if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q .; then
    log_warning "Not authenticated with gcloud"
    echo ""
    echo "Please authenticate with your Google account:"
    gcloud auth login
    gcloud auth application-default login
else
    log_success "Already authenticated with gcloud"
fi

# Set project
log_info "Setting project to ${PROJECT_ID}..."
gcloud config set project ${PROJECT_ID} 2>/dev/null || {
    log_error "Failed to set project. Please ensure the project exists."
    exit 1
}

################################################################################
# Run permission setup
################################################################################

log_step "Setting up IAM Permissions"

if [ -f "./setup-iam-permissions.sh" ]; then
    log_info "Running IAM permission setup..."
    # Create a temporary expect script to auto-answer prompts
    cat > /tmp/setup-iam-auto.sh << 'EXPECT_SCRIPT'
#!/usr/bin/expect -f
spawn ./setup-iam-permissions.sh
expect "Do you want to proceed?"
send "y\r"
expect "Do you want to grant optional roles as well?"
send "n\r"
expect "Do you want to create a dedicated service account for Terraform?"
send "n\r"
expect eof
EXPECT_SCRIPT
    
    if command -v expect &> /dev/null; then
        chmod +x /tmp/setup-iam-auto.sh
        /tmp/setup-iam-auto.sh
        rm /tmp/setup-iam-auto.sh
    else
        log_warning "expect not installed, running setup interactively..."
        bash ./setup-iam-permissions.sh
    fi
else
    log_error "setup-iam-permissions.sh not found!"
    exit 1
fi

################################################################################
# Verify permissions
################################################################################

log_step "Verifying Permissions"

if [ -f "./check-permissions.sh" ]; then
    log_info "Running permission check..."
    bash ./check-permissions.sh | tail -20
else
    log_warning "check-permissions.sh not found, skipping verification"
fi

################################################################################
# Create terraform.tfvars
################################################################################

log_step "Creating Terraform Configuration"

log_info "Creating terraform.tfvars file..."
cat > terraform.tfvars << EOL
# Auto-generated configuration
project_id = "${PROJECT_ID}"
region     = "${REGION}"
prefix     = "${PREFIX}"

# Environment configuration
environment = "dev"
labels = {
  created_by = "quick-setup"
  owner      = "${USER_EMAIL%%@*}"
  team       = "data-platform"
}

# Note: Vertex AI Workbench removed from template (create manually if needed)

# Sample data configuration
create_sample_data = true
sample_data_config = {
  num_customers    = 10000
  num_transactions = 100000
  num_products     = 1000
}

# Storage configuration
force_destroy = false  # Set to true in dev environments
EOL

log_success "terraform.tfvars created"

################################################################################
# Initialize Terraform
################################################################################

log_step "Initializing Terraform"

log_info "Running terraform init..."
terraform init -upgrade

################################################################################
# Plan Terraform deployment
################################################################################

log_step "Planning Infrastructure Deployment"

log_info "Running terraform plan..."
terraform plan -out=tfplan

# Count resources to be created
RESOURCE_COUNT=$(terraform show -json tfplan 2>/dev/null | grep -o '"create"' | wc -l)
log_info "Will create ${RESOURCE_COUNT} resources"

################################################################################
# Deployment confirmation
################################################################################

log_step "Deployment Confirmation"

echo ""
echo -e "${BOLD}Ready to deploy the following:${NC}"
echo "- ${RESOURCE_COUNT} cloud resources"
echo "- VPC network and subnets"
echo "- BigQuery datasets and tables"
echo "- Dataplex data lake and catalog"
echo "- Vertex AI datasets and ML infrastructure (no workbench)"
echo "- Cloud Storage buckets"
echo "- IAM service accounts and bindings"
echo ""
echo -e "${YELLOW}Estimated monthly cost: \$200-500 (varies by usage)${NC}"
echo ""

read -p "Do you want to deploy the infrastructure? (yes/no): " -r
echo ""

if [[ ! $REPLY =~ ^[Yy][Ee][Ss]$ ]]; then
    log_warning "Deployment cancelled by user"
    exit 0
fi

################################################################################
# Deploy infrastructure
################################################################################

log_step "Deploying Infrastructure"

log_info "Running terraform apply..."
terraform apply tfplan

# Check if deployment was successful
if [ $? -eq 0 ]; then
    log_success "Infrastructure deployed successfully!"
else
    log_error "Deployment failed. Please check the errors above."
    exit 1
fi

################################################################################
# Post-deployment actions
################################################################################

log_step "Post-Deployment Configuration"

# Get outputs
log_info "Retrieving deployment outputs..."
terraform output -json > deployment-outputs.json

# Extract key information  
PROJECT_ID=$(terraform output -raw project_id)

################################################################################
# Display access information
################################################################################

log_step "Access Information"

echo ""
echo -e "${BOLD}🎉 Deployment Complete!${NC}"
echo ""
echo "Your ML Data Platform is ready. Here's how to access it:"
echo ""
echo "1. Create Vertex AI Workbench manually (if needed):"
echo "   ${BOLD}https://console.cloud.google.com/vertex-ai/workbench/instances?project=${PROJECT_ID}${NC}"
echo ""
echo "2. BigQuery Datasets:"
echo "   ${BOLD}https://console.cloud.google.com/bigquery?project=${PROJECT_ID}${NC}"
echo ""
echo "3. Dataplex Lake:"
echo "   ${BOLD}https://console.cloud.google.com/dataplex/lakes?project=${PROJECT_ID}${NC}"
echo ""
echo "4. Cloud Storage Buckets:"
echo "   ${BOLD}https://console.cloud.google.com/storage/browser?project=${PROJECT_ID}${NC}"
echo ""

################################################################################
# Quick start commands
################################################################################

log_step "Quick Start Commands"

cat << EOL

# Note: Create Vertex AI Workbench manually if needed at:
# https://console.cloud.google.com/vertex-ai/workbench/instances?project=${PROJECT_ID}

# List BigQuery datasets:
bq ls --project_id=${PROJECT_ID}

# List Dataplex lakes:
gcloud dataplex lakes list --project=${PROJECT_ID} --location=${REGION}

# View sample data:
bq query --project_id=${PROJECT_ID} --use_legacy_sql=false \\
  'SELECT * FROM \`${PROJECT_ID}.${PREFIX}_raw_data.sample_customers\` LIMIT 10'

# Access outputs:
terraform output

EOL

################################################################################
# Save deployment info
################################################################################

log_info "Saving deployment information..."

cat > deployment-info.txt << EOL
ML Data Platform Deployment Information
========================================
Date: $(date)
Project ID: ${PROJECT_ID}
Region: ${REGION}
User: ${USER_EMAIL}
Prefix: ${PREFIX}
Resources Created: ${RESOURCE_COUNT}

Access URLs:
- Create Workbench manually: https://console.cloud.google.com/vertex-ai/workbench/instances?project=${PROJECT_ID}
- BigQuery: https://console.cloud.google.com/bigquery?project=${PROJECT_ID}
- Dataplex: https://console.cloud.google.com/dataplex/lakes?project=${PROJECT_ID}
- Storage: https://console.cloud.google.com/storage/browser?project=${PROJECT_ID}

To destroy this infrastructure:
terraform destroy

EOL

log_success "Deployment information saved to deployment-info.txt"

################################################################################
# Cleanup
################################################################################

log_step "Optional Next Steps"

echo "1. Upload your data to the raw-data bucket"
echo "2. Create Vertex AI Workbench manually for notebook development"
echo "3. Build data pipelines with Dataflow"
echo "4. Set up monitoring dashboards"
echo "5. Configure data quality rules in Dataplex"
echo ""

log_success "✅ Quick setup completed successfully!"
echo ""
echo -e "${BOLD}Happy Machine Learning! 🚀${NC}"